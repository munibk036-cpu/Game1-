# Rayan City Racer — Starter Prototype

This is a lightweight playable browser prototype, not a finished AAA/open-world game.
It uses HTML, CSS, JavaScript and Three.js.

## Run
1. Extract the ZIP.
2. Open `web-prototype/index.html` in Chrome or Edge.
3. Internet is required to load Three.js from its CDN.

## Controls
W/Up accelerate · S/Down brake · A/Left and D/Right steer · Space handbrake · H horn · C camera · P pause · R restart.
On-screen buttons work with mouse/touch.

## Included
3D road and city blocks, sports car, traffic, third/first-person camera toggle, accelerator/brake/steering/handbrake/horn, speedometer, credits, timer, minimap, pause/restart, simple audio cues.

## Limitations
This is a starter prototype with simplified models, physics, traffic and sounds. It is not a fully realistic open-world game. The Unreal Engine 5 production version in the PRD is a separate, larger project requiring more assets and development.
